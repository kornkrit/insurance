-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Nov 22, 2016 at 09:02 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `insurance`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `cars`
-- 

CREATE TABLE `cars` (
  `id` int(5) unsigned zerofill NOT NULL auto_increment,
  `member_id` int(5) unsigned zerofill NOT NULL,
  `mander` text NOT NULL,
  `year` year(4) NOT NULL,
  `type` text NOT NULL,
  `vehicle_registration` varchar(15) NOT NULL,
  `country` text NOT NULL,
  `copy_of_car` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=57 ;

-- 
-- Dumping data for table `cars`
-- 

INSERT INTO `cars` VALUES (00001, 00000, '', 0000, '', '', '', '');
INSERT INTO `cars` VALUES (00002, 00000, 'Toyota', 0000, 'à¸à¸£à¸°à¸šà¸°à¸ªà¸­à¸‡à¸•à¸­à¸™', '2à¸à¸“2620', '', '');
INSERT INTO `cars` VALUES (00003, 00000, 'Toyota', 0000, 'à¸à¸£à¸°à¸šà¸°à¸ªà¸­à¸‡à¸•à¸­à¸™', '2à¸à¸“2620', '', '');
INSERT INTO `cars` VALUES (00004, 00000, 'Toyota', 0000, 'à¸à¸£à¸°à¸šà¸°à¸ªà¸­à¸‡à¸•à¸­à¸™', '2à¸à¸“2620', '', '');
INSERT INTO `cars` VALUES (00005, 00000, 'Toyota', 0000, 'à¸à¸£à¸°à¸šà¸°à¸ªà¸­à¸‡à¸•à¸­à¸™', '2à¸à¸“2620', '', '');
INSERT INTO `cars` VALUES (00006, 00000, 'Toyota', 0000, 'à¸à¸£à¸°à¸šà¸°à¸ªà¸­à¸‡à¸•à¸­à¸™', '2à¸à¸“2620', '', '');
INSERT INTO `cars` VALUES (00007, 00000, 'Toyota', 0000, 'à¸à¸£à¸°à¸šà¸°à¸ªà¸­à¸‡à¸•à¸­à¸™', '2à¸à¸“2620', '', '');
INSERT INTO `cars` VALUES (00008, 00010, 'Toyota', 0000, 'à¸à¸£à¸°à¸šà¸°à¸ªà¸­à¸‡à¸•à¸­à¸™', '2à¸à¸“2620', '', '');
INSERT INTO `cars` VALUES (00009, 00011, 'Toyota', 0000, 'à¸à¸£à¸°à¸šà¸°à¸ªà¸­à¸‡à¸•à¸­à¸™', '2à¸à¸“2620', '', '');
INSERT INTO `cars` VALUES (00010, 00012, 'Toyota', 0000, 'à¸à¸£à¸°à¸šà¸°à¸ªà¸­à¸‡à¸•à¸­à¸™', '2à¸à¸“2620', '', '');
INSERT INTO `cars` VALUES (00011, 00013, 'Toyota', 0000, 'à¸à¸£à¸°à¸šà¸°à¸ªà¸­à¸‡à¸•à¸­à¸™', '2à¸à¸“2620', '', '');
INSERT INTO `cars` VALUES (00012, 00014, 'Toyota', 0000, 'à¸à¸£à¸°à¸šà¸°à¸ªà¸­à¸‡à¸•à¸­à¸™', '2à¸à¸“2620', '', '');
INSERT INTO `cars` VALUES (00013, 00015, 'Toyota', 0000, 'à¸à¸£à¸°à¸šà¸°à¸ªà¸­à¸‡à¸•à¸­à¸™', 'à¸4571', '', '');
INSERT INTO `cars` VALUES (00014, 00016, 'Toyota', 0000, 'à¸à¸£à¸°à¸šà¸°à¸ªà¸­à¸‡à¸•à¸­à¸™', 'à¸4571', '', '');
INSERT INTO `cars` VALUES (00015, 00017, 'Toyota', 0000, 'à¸à¸£à¸°à¸šà¸°à¸ªfdsfsdfsfsà¸­à¸‡à¸•à¸­à¸™', 'à¸4571', 'fsdfsf', '');
INSERT INTO `cars` VALUES (00016, 00018, 'Toyota', 0000, 'à¸à¸£à¸°à¸šà¸°à¸ªà¸­à¸‡à¸•à¸­à¸™', 'à¸4571', '', '');
INSERT INTO `cars` VALUES (00017, 00019, 'Toyota', 0000, 'à¸à¸£à¸°à¸šà¸°à¸ªà¸­à¸‡à¸•à¸­à¸™', '', '', '');
INSERT INTO `cars` VALUES (00018, 00020, 'Toyota', 0000, 'à¸à¸£à¸°à¸šà¸°à¸ªà¸­à¸‡à¸•à¸­à¸™', '', '', '');
INSERT INTO `cars` VALUES (00019, 00021, '', 0000, '', '', '', '');
INSERT INTO `cars` VALUES (00020, 00022, '', 0000, '', '', '', '');
INSERT INTO `cars` VALUES (00021, 00023, '', 0000, '', '', '', '');
INSERT INTO `cars` VALUES (00022, 00024, '', 0000, '', '', '', '');
INSERT INTO `cars` VALUES (00024, 00026, 'Honda', 0000, 'à¸£à¸¢.1', '2à¸à¸“2620', 'à¸à¸£à¸¸à¸‡à¹€à¸—à¸žà¸¡à¸«à¸²à¸™à¸„à¸£', '');
INSERT INTO `cars` VALUES (00037, 00039, 'Chevrolet', 2010, 'à¸£à¸¢.1', '3 à¸à¸— 4551', 'à¸à¸£à¸¸à¸‡à¹€à¸—à¸žà¸¡à¸«à¸²à¸™à¸„à¸£', '');
INSERT INTO `cars` VALUES (00054, 00036, 'Audi', 1988, 'à¸£à¸¢.1', '', 'à¸à¸²à¸à¸ˆà¸™à¸šà¸¸à¸£à¸µ', '');
INSERT INTO `cars` VALUES (00055, 00038, 'Mitsubishi', 1988, 'à¸£à¸¢.1', 'vf', 'à¸™à¸£à¸²à¸˜à¸´à¸§à¸²à¸ª', '');
INSERT INTO `cars` VALUES (00035, 00037, 'Chevrolet', 2010, 'à¸£à¸¢.1', '3 à¸à¸— 4551', 'à¸à¸£à¸¸à¸‡à¹€à¸—à¸žà¸¡à¸«à¸²à¸™à¸„à¸£', '');
INSERT INTO `cars` VALUES (00036, 00038, 'Chevrolet', 2010, 'à¸£à¸¢.1', '3 à¸à¸— 4551', 'à¸à¸£à¸¸à¸‡à¹€à¸—à¸žà¸¡à¸«à¸²à¸™à¸„à¸£', '');
INSERT INTO `cars` VALUES (00056, 00036, 'Ford', 1989, 'à¸£à¸¢.2', '2 à¸à¸ 566', 'à¸Šà¸±à¸¢à¸ à¸¹à¸¡à¸´', '');
INSERT INTO `cars` VALUES (00053, 00036, 'BMW', 2013, 'à¸£à¸¢.1', '2à¸à¸“5566', 'à¸à¸£à¸¸à¸‡à¹€à¸—à¸žà¸¡à¸«à¸²à¸™à¸„à¸£', '');
INSERT INTO `cars` VALUES (00050, 00052, 'BMW', 2009, 'à¸£à¸¢.1', '2 à¸à¸“ 2620', 'à¸à¸£à¸¸à¸‡à¹€à¸—à¸žà¸¡à¸«à¸²à¸™à¸„à¸£', '');
INSERT INTO `cars` VALUES (00051, 00052, 'Audi', 1996, 'à¸£à¸¢.1', '2 à¸à¸“ 4589', 'à¸à¸£à¸¸à¸‡à¹€à¸—à¸žà¸¡à¸«à¸²à¸™à¸„à¸£', '');
INSERT INTO `cars` VALUES (00052, 00052, 'Hyundai', 1989, 'à¸£à¸¢.1', 'fd', 'à¸šà¸¶à¸‡à¸à¸²à¸¬', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `insurance_policy`
-- 

CREATE TABLE `insurance_policy` (
  `id` int(5) unsigned zerofill NOT NULL auto_increment,
  `member_id` int(5) unsigned zerofill NOT NULL,
  `cars_id` int(5) unsigned zerofill NOT NULL,
  `company` text NOT NULL,
  `class` text NOT NULL,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `net_cowrie` double NOT NULL,
  `duty` double NOT NULL,
  `tax` double NOT NULL,
  `total` double NOT NULL,
  `comission` double NOT NULL,
  `payment` double NOT NULL,
  `discount` double NOT NULL,
  `paid_date` date NOT NULL,
  `note` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=48 ;

-- 
-- Dumping data for table `insurance_policy`
-- 

INSERT INTO `insurance_policy` VALUES (00047, 00036, 00056, 'smk', '1', '2013-07-15', '2014-07-15', 15660, 63, 1100.61, 16823.61, 16823.61, 0, 2, '2013-07-15', '');
INSERT INTO `insurance_policy` VALUES (00044, 00036, 00053, 'cp', '1', '2013-07-14', '2014-07-14', 12500, 50, 878.5, 13428.5, 13428.5, 0, 2, '2013-07-14', '');
INSERT INTO `insurance_policy` VALUES (00043, 00052, 00052, 'cp', '1', '2013-07-10', '2014-07-10', 4500, 18, 316.26, 4834.26, 4834.26, 0, 0, '2013-07-14', '');
INSERT INTO `insurance_policy` VALUES (00042, 00052, 00051, 'cp', '1', '2013-07-14', '2014-07-14', 12500, 50, 878.5, 13428.5, 13428.5, 0, 10, '2013-07-14', '');
INSERT INTO `insurance_policy` VALUES (00041, 00052, 00050, 'smk', '1', '2013-07-14', '2014-07-14', 25000, 100, 1757, 26857, 26857, 0, 5, '2013-07-14', '');
INSERT INTO `insurance_policy` VALUES (00021, 00032, 00030, 'smk', '1', '0000-00-00', '0000-00-00', 0, 0, 0, 0, 0, 0, 0, '0000-00-00', '');
INSERT INTO `insurance_policy` VALUES (00023, 00034, 00032, 'cp', '1', '2013-07-12', '2013-07-18', 0, 0, 0, 0, 0, 0, 0, '0000-00-00', '');
INSERT INTO `insurance_policy` VALUES (00046, 00038, 00055, 'cp', '2', '2013-07-09', '2014-07-06', 50000, 200, 3514, 53714, 53714, 0, 1, '2013-07-14', '');
INSERT INTO `insurance_policy` VALUES (00045, 00036, 00054, '', '', '0000-00-00', '0000-00-00', 0, 0, 0, 0, 0, 0, 0, '0000-00-00', '');
INSERT INTO `insurance_policy` VALUES (00026, 00037, 00035, 'cp', '1', '2013-07-12', '2014-07-12', 40, 1, 2.87, 43.87, 0, 43.87, 0, '2013-07-12', '');
INSERT INTO `insurance_policy` VALUES (00027, 00038, 00036, 'cp', '1', '2013-07-12', '2014-07-12', 50000, 200, 3514, 53714, 53714, 0, 0, '2013-07-12', '');
INSERT INTO `insurance_policy` VALUES (00028, 00039, 00037, 'cp', '1', '2013-07-12', '2014-07-12', 50000, 200, 3514, 53714, 53714, 0, 0, '2013-07-12', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `member`
-- 

CREATE TABLE `member` (
  `id` int(5) unsigned zerofill NOT NULL auto_increment,
  `fullname` text NOT NULL,
  `surname` text NOT NULL,
  `address` text NOT NULL,
  `phone` text NOT NULL,
  `email` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=53 ;

-- 
-- Dumping data for table `member`
-- 

INSERT INTO `member` VALUES (00001, 'kornkrit', 'Supayanant', '9/7', '0894514236', 'kornkrit.s@hotmail.com');
INSERT INTO `member` VALUES (00002, 'kornkrit', 'Supayanant', '9/6', '0894514236', 'kornkrit.s@hotmail.com');
INSERT INTO `member` VALUES (00003, 'kornkrit', 'Supayanant', '9/6', '0894514236', 'kornkrit.s@hotmail.com');
INSERT INTO `member` VALUES (00004, 'kornkrit', 'Supayanant', '9/6', '0894514236', 'kornkrit.s@hotmail.com');
INSERT INTO `member` VALUES (00005, 'kornkrit', 'Supayanant', '9/6', '0894514236', 'kornkrit.s@hotmail.com');
INSERT INTO `member` VALUES (00006, 'kornkrit', 'Supayanant', '9/6', '0894514236', 'kornkrit.s@hotmail.com');
INSERT INTO `member` VALUES (00007, 'kornkrit', 'Supayanant', '9/6', '0894514236', 'kornkrit.s@hotmail.com');
INSERT INTO `member` VALUES (00008, 'kornkrit', 'Supayanant', '9/6', '0894514236', 'kornkrit.s@hotmail.com');
INSERT INTO `member` VALUES (00009, 'kornkrit', 'Supayanant', '9/6', '0894514236', 'kornkrit.s@hotmail.com');
INSERT INTO `member` VALUES (00010, 'kornkrit', 'Supayanant', '9/6', '0894514236', 'kornkrit.s@hotmail.com');
INSERT INTO `member` VALUES (00011, 'kornkrit', 'Supayanant', 'Bangkok', '0894154236', 'kornkrit.s@hotmail.com');
INSERT INTO `member` VALUES (00012, 'kornkrit', 'Supayanant', 'Bangkok', '0894154236', 'kornkrit.s@hotmail.com');
INSERT INTO `member` VALUES (00013, 'kornkrit', 'Supayanant', 'Bangkok', '0894154236', 'kornkrit.s@hotmail.com');
INSERT INTO `member` VALUES (00014, 'kornkrit', 'Supayanant', 'Bangkok', '0894154236', 'kornkrit.s@hotmail.com');
INSERT INTO `member` VALUES (00015, 'Vasu', 'Supayanant', 'Bangkok', '0894514236', 'vasu_sup@yahoo.com');
INSERT INTO `member` VALUES (00016, 'Vasu', 'Supayanant', 'Bangkok', '0894514236', 'vasu_sup@yahoo.com');
INSERT INTO `member` VALUES (00017, 'Vasu', 'Supayanant', 'Bangkok', '0894514236', 'vasu_sup@yahoo.com');
INSERT INTO `member` VALUES (00018, 'Vasu', 'Supayanant', 'Bangkok', '0894514236', 'vasu_sup@yahoo.com');
INSERT INTO `member` VALUES (00019, '', '', '', '', '');
INSERT INTO `member` VALUES (00020, '', '', '', '', '');
INSERT INTO `member` VALUES (00021, '', '', '', '', '');
INSERT INTO `member` VALUES (00022, '', '', '', '', '');
INSERT INTO `member` VALUES (00023, '', '', '', '', '');
INSERT INTO `member` VALUES (00024, '', '', '', '', '');
INSERT INTO `member` VALUES (00025, 'à¸¨à¸£à¸µà¸ªà¸¸à¸§à¸£à¸£à¸“', 'à¸ªà¸¸à¸›à¸²à¸¢à¸™à¸±à¸™à¸•à¹Œ', 'à¸à¸£à¸¸à¸‡à¹€à¸—à¸ž', '0894154236', 'kornkrit.s@hotmail.com');
INSERT INTO `member` VALUES (00026, '?????????????', '??????????????????????????????', '9/7 ???????????? 15', '0894154236', 'kornkrit.s@hotmail.com');
INSERT INTO `member` VALUES (00027, 'kornkrit', 'Supayanant', '45', '0894154236', 'kornkrit.s@hotmail.com');
INSERT INTO `member` VALUES (00028, 'à¸¨à¸£à¸µà¸ªà¸¸à¸§à¸£à¸£à¸“', 'à¸ªà¸¸à¸›à¸²à¸¢à¸™à¸±à¸™à¸•à¹Œ', '48/5 à¸«à¸¡à¸¹à¹ˆ 3 à¸‹à¸­à¸¢à¹€à¸‡à¸´à¸™à¸­à¸¸à¸”à¸¡ 1 à¹à¸‚à¸§à¸‡à¸šà¸²à¸‡à¹€à¸Šà¸·à¸­à¸à¸«à¸™à¸±à¸‡ à¹€à¸‚à¸•à¸•à¸¥à¸´à¹ˆà¸‡à¸Šà¸±à¸™ à¸à¸£à¸¸à¸‡à¹€à¸—à¸žà¸¡à¸«à¸²à¸™à¸„à¸£ 10170', '0863673863', 'vasu_sup@yahoo.com');
INSERT INTO `member` VALUES (00029, 'à¸à¸£à¸à¸¤à¸¨', 'à¸ªà¸¸à¸›à¸²à¸¢à¸™à¸±à¸™à¸•à¹Œ', '48/5 à¸«à¸¡à¸¹à¹ˆ 3 à¸‹à¸­à¸¢à¹€à¸‡à¸´à¸™à¸­à¸¸à¸”à¸¡ 1 à¹à¸‚à¸§à¸‡à¸šà¸²à¸‡à¹€à¸Šà¸·à¸­à¸à¸«à¸™à¸±à¸‡ à¹€à¸‚à¸•à¸•à¸¥à¸´à¹ˆà¸‡à¸Šà¸±à¸™ à¸à¸£à¸¸à¸‡à¹€à¸—à¸žà¸¡à¸«à¸²à¸™à¸„à¸£ 10170', '0863673863', 'vasu_sup@yahoo.com');
INSERT INTO `member` VALUES (00030, 'à¸„à¸¸à¸“à¸«à¸‡à¸©à¹Œ', '', '', '0863673863', 'kornkrit.s@hotmail.com');
INSERT INTO `member` VALUES (00031, 'à¸à¸£à¸à¸¤à¸Š', 'à¸ªà¸¸à¸›à¸²à¸¢à¸™à¸±à¸™à¸•à¹Œ', 'à¸”à¸­à¸™à¸«à¸­à¸¢à¸«à¸¥à¸­à¸”', '0863673863', 'vasu_sup@yahoo.com');
INSERT INTO `member` VALUES (00032, '', '', '', '', '');
INSERT INTO `member` VALUES (00033, '', '', '', '', '');
INSERT INTO `member` VALUES (00034, '', '', '', '', '');
INSERT INTO `member` VALUES (00035, '', '', '', '', '');
INSERT INTO `member` VALUES (00036, 'à¸à¸£à¸à¸¤à¸¨', 'à¸ªà¸¸à¸›à¸²à¸¢à¸™à¸±à¸™à¸•à¹Œ', '9/7 à¸«à¸¡à¸¹à¹ˆ 15 à¸‹à¸­à¸¢à¹€à¸‡à¸´à¸™à¸­à¸¸à¸”à¸¡ 1 à¹à¸‚à¸§à¸‡à¸šà¸²à¸‡à¹€à¸Šà¸·à¸­à¸à¸«à¸™à¸±à¸‡ à¹€à¸‚à¸•à¸•à¸¥à¸´à¹ˆà¸‡à¸Šà¸±à¸™ 10170', '0894154236', 'kornkrit.s@hotmail.com');
INSERT INTO `member` VALUES (00037, 'à¸à¸£à¸à¸¤à¸¨', 'à¸ªà¸¸à¸›à¸²à¸¢à¸™à¸±à¸™à¸•à¹Œ', '9/7 à¸«à¸¡à¸¹à¹ˆ 15 à¸‹à¸­à¸¢à¹€à¸‡à¸´à¸™à¸­à¸¸à¸”à¸¡ 1 à¹à¸‚à¸§à¸‡à¸šà¸²à¸‡à¹€à¸Šà¸·à¸­à¸à¸«à¸™à¸±à¸‡ à¹€à¸‚à¸•à¸•à¸¥à¸´à¹ˆà¸‡à¸Šà¸±à¸™ 10170', '0894154236', 'kornkrit.s@hotmail.com');
INSERT INTO `member` VALUES (00038, 'à¸à¸£à¸à¸¤à¸¨', 'à¸ªà¸¸à¸›à¸²à¸¢à¸™à¸±à¸™à¸•à¹Œ', '9/7 à¸«à¸¡à¸¹à¹ˆ 15 à¸‹à¸­à¸¢à¹€à¸‡à¸´à¸™à¸­à¸¸à¸”à¸¡ 1 à¹à¸‚à¸§à¸‡à¸šà¸²à¸‡à¹€à¸Šà¸·à¸­à¸à¸«à¸™à¸±à¸‡ à¹€à¸‚à¸•à¸•à¸¥à¸´à¹ˆà¸‡à¸Šà¸±à¸™ 10170', '0894154236', 'kornkrit.s@hotmail.com');
INSERT INTO `member` VALUES (00039, 'à¸à¸£à¸à¸¤à¸¨', 'à¸ªà¸¸à¸›à¸²à¸¢à¸™à¸±à¸™à¸•à¹Œ', '9/7 à¸«à¸¡à¸¹à¹ˆ 15 à¸‹à¸­à¸¢à¹€à¸‡à¸´à¸™à¸­à¸¸à¸”à¸¡ 1 à¹à¸‚à¸§à¸‡à¸šà¸²à¸‡à¹€à¸Šà¸·à¸­à¸à¸«à¸™à¸±à¸‡ à¹€à¸‚à¸•à¸•à¸¥à¸´à¹ˆà¸‡à¸Šà¸±à¸™ 10170', '0894154236', 'kornkrit.s@hotmail.com');
INSERT INTO `member` VALUES (00040, '', '', '', '', '');
INSERT INTO `member` VALUES (00041, '', '', '', '', '');
INSERT INTO `member` VALUES (00042, '', '', '', '', '');
INSERT INTO `member` VALUES (00043, '', '', '', '', '');
INSERT INTO `member` VALUES (00044, '', '', '', '', '');
INSERT INTO `member` VALUES (00045, '', '', '', '', '');
INSERT INTO `member` VALUES (00046, '', '', '', '', '');
INSERT INTO `member` VALUES (00047, '', '', '', '', '');
INSERT INTO `member` VALUES (00048, '', '', '', '', '');
INSERT INTO `member` VALUES (00049, '', '', '', '', '');
INSERT INTO `member` VALUES (00050, '', '', '', '', '');
INSERT INTO `member` VALUES (00051, '', '', '', '', '');
INSERT INTO `member` VALUES (00052, 'Vasu', 'Supayanant', '48/5 moo 3 soi ngerudom 1 bangchaengnung talingchan district bangkok 10170', '0863673863', 'vasu_sup@yahoo.com');
